﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;



namespace reg
{
    public partial class WebForm18 : System.Web.UI.Page
    {

        //offers o = new offers();
        //  business_access_layer bal = new business_access_layer();
        //       protected void Page_Load(object sender, EventArgs e)
        //       {

        //           if (!IsPostBack)
        //           {
        //               GrdBInd();
        //           }
        //       }
        //       private void GrdBInd()
        //       {
        //           DataSet DL = new DataSet();
        //           DL = bal.Offers();
        //           GridView1.DataSource = DL;
        //           GridView1.DataBind();
        //       }    
        //       }
    }
}