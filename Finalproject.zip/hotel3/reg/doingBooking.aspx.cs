﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;


namespace reg
{
    public partial class WebForm13 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            TextBox1.Text = Session["hotelnm"].ToString();
            TextBox2.Text = Session["Cname"].ToString();
            TextBox3.Text = Session["rentofroom"].ToString();


        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Session["hotelnm"] = TextBox1.Text;
            Session["Cname"] = TextBox2.Text;
            Session["rentofroom"] = TextBox3.Text;
            Session["rooms"] = DropDownList1.SelectedValue;
            Response.Redirect("Booking2.aspx");
        }
    }
}