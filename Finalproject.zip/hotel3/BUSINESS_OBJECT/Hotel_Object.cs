﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BUSINESS_OBJECT
{
    public class hotel_object
    {
        public string hotel_name { get; set; }
        public string city_name { get; set; }
        public string hotel_desc { get; set; }
        public string no_of_rooms { get; set; }
        public string rent_of_room { get; set; }
        public string offer_id { get; set; }
    }
    }

