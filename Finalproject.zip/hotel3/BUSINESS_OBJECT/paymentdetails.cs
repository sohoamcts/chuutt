﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BUSINESS_OBJECT
{
  public class paymentdetails
    {
        public string PID { get; set; }
        public string BID { get; set; }
        public string status { get; set; }
        public string amount { get; set; }
        //public string Cname { get; set; }

    }
}
