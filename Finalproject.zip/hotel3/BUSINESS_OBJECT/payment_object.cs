﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BUSINESS_OBJECT
{
   public class payment_object
    {
       public string pid { get; set; }
        public string fkbankid { get; set; }
        public string pkcreditcardno { get; set; }
        public string cardtype { get; set; }
        public string nameoncard { get; set; }
        public string expirydate { get; set; }
        public string fkbookingid { get; set; }
        public string bankname { get; set; }
        public string cardnum { get; set; }
        
    }
}
