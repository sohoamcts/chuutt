﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace reg
{
    public partial class WebForm7 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            if ((DropDownList1.SelectedValue == "Insert" || DropDownList1.SelectedValue == "Update") && DropDownList2.SelectedValue == "Hotel")
            {
                Response.Redirect("InsertHotel.aspx");
            }
            else if ((DropDownList1.SelectedValue == "Insert" || DropDownList1.SelectedValue == "Update") && DropDownList2.SelectedValue == "City")
            {
                Response.Redirect("InsertCity.aspx");
            }
            else if ((DropDownList1.SelectedValue == "Insert" || DropDownList1.SelectedValue == "Update") && DropDownList2.SelectedValue == "Offer")
            {
                Response.Redirect("InsertOffer.aspx");
            }
        }
    }
}