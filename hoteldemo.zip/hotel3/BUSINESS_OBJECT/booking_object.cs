﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BUSINESS_OBJECT
{
    class booking_object
    {
        public int id { get; set; }
        public int noofrooms { get; set; }
        public string hotelname { get; set; }
        public string amount { get; set; }
        public string Cname {get; set;}
    }
}
