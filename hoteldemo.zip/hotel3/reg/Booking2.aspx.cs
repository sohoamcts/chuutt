﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BAL;
using BUSINESS_OBJECT;

namespace reg
{
    public partial class Booking2 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Random rd = new Random();
            int num = rd.Next();
            TextBox1.Text = num.ToString();
            TextBox2.Text = Session["rooms"].ToString();
            int n = Convert.ToInt32(TextBox2.Text);
            TextBox3.Text = Session["hotelnm"].ToString();
            TextBox5.Text = Session["Cname"].ToString();
            TextBox4.Text = Session["rentofroom"].ToString();
            int rent = Convert.ToInt32(TextBox4.Text);
            TextBox4.Text = (n * rent).ToString();
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            Session["BID"] = TextBox1.Text;
            Response.Redirect("Payment.aspx");
        }

        

        protected void Button1_Click(object sender, EventArgs e)
        {
            //here we have to write the code for insert a booking and simultaneously display that
            //code in the gridview below using bind() function call
            booking_object bo = new booking_object();
            bo.id = TextBox1.Text;
            bo.noofrooms = TextBox2.Text;
            bo.hotelname = TextBox3.Text;
            bo.amount = TextBox4.Text;
            bo.Cname = TextBox5.Text;
            
            register_bal ro = new register_bal();
            string msg = ro.insertbooking(bo);
            Label lb = new Label();
            lb.Text = "Insert Succesfull";
            GridView1.DataSource = ro.searchbooking();
        }
    }
}